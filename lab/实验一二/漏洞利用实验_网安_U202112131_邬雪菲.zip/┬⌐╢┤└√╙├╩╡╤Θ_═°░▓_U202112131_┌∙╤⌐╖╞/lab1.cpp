#include <iostream>
#include <cstdio>
#include <cstdlib>
using namespace std;

using Elf64_Addr = uint64_t;
using Elf64_Off = uint64_t;
using Elf64_Half = uint16_t;
using Elf64_Word = uint32_t;
using Elf64_Sword = int32_t;
using Elf64_Xword = uint64_t;
using Elf64_Sxword = int64_t;
/*
Elf64_Half = 2 Bytes
Elf64_Word = 4 Bytes
Elf64_Addr = 8 Bytes
Elf64_Off = 8 Bytes
Elf64_Xword = 8 Bytes
*/
typedef struct
{
    /******************************************
    16字节的MagicNumber用于标识ELF文件
    0-3字节固定为\0x7f 'ELF'
    4（EI_CLASS）：00为非法文件，01位32位，02为64位。
    5（EI_DATA）：00为非法数据编码，01为小端序，02为大端序。
    6（EI_VERSION）：文件版本，固定为01。
    7（EI_OSABI）：操作系统ABI标识（实际未使用）。
    8（EI_ABIVERSION）：ABI版本（实际未使用）。
    9~15：对齐填充，无实际意义。
    ******************************************/
    unsigned char e_ident[16];
    Elf64_Half e_type;      // 文件格式，可执行文件ET_EXEC取值为2
    Elf64_Half e_machine;   // CPU架构
    Elf64_Word e_version;   // ELF文件版本
    Elf64_Addr e_entry;     // 程序入口点
    Elf64_Off e_phoff;      // 程序头表偏移地址，即第一个Program Header所在文件中的位置
    Elf64_Off e_shoff;      // 节头表偏移地址，即第一个Section Header所在文件中的位置
    Elf64_Word e_flags;     // 处理器标志位
    Elf64_Half e_ehsize;    // ELF Header大小，32位是52字节，64位是64字节
    Elf64_Half e_phentsize; // 程序头表表项大小
    Elf64_Half e_phnum;     // 程序头表数目，即有几个段
    Elf64_Half e_shentsize; // 节头表表项大小
    Elf64_Half e_shnum;     // 节头表数目，即有几个节
    Elf64_Half e_shstrndx;  // 节头表中与节名字表对应的表项索引。即.shstrtab节头表是第几个
} Elf64_Ehdr;

typedef struct
{
    Elf64_Word sh_name;       // 节名在节名表中的偏移
    Elf64_Word sh_type;       // 节类型
    Elf64_Xword sh_flags;     // 节标志位,1可执行，2可写，4可读
    Elf64_Addr sh_addr;       // 运行时节的虚拟地址VA
    Elf64_Off sh_offset;      // 运行时节的物理地址PA
    Elf64_Xword sh_size;      // 节的大小
    Elf64_Word sh_link;       // 链接到其他节头的索引号
    Elf64_Word sh_info;       // 节的附加信息
    Elf64_Xword sh_addralign; // 节内容的对齐粒度
    Elf64_Xword sh_entsize;   // 该节中每个表项的大小
} Elf64_Shdr;

typedef struct
{
    Elf64_Half p_type;    // 段类型
    Elf64_Half p_flags;   // 段标志位，1可执行，2可写，4可读
    Elf64_Off p_offset;   // 段内容偏移
    Elf64_Addr p_vaddr;   // 运行时段的虚拟地址VA
    Elf64_Addr p_paddr;   // 运行时段的物理地址PA
    Elf64_Xword p_filesz; // 段在ELF文件中占用的大小
    Elf64_Xword p_memsz;  // 段在内存中占用的大小
    Elf64_Xword p_align;  // 段内容的对齐粒度
} Elf64_Phdr;

int main()
{
    char filename[1005];
    FILE *fp;
    printf("Please input the filename:\n");
    scanf("%s", filename);
    // 打开ELF文件
    fp = fopen(filename, "r");
    if (fp == NULL)
    {
        printf("Open file failed!\n");
        exit(0);
    }
    // 解析文件头
    Elf64_Ehdr elf_head;
    int shnum;
    // 读取ELF Header到elf_head中
    fread(&elf_head, sizeof(Elf64_Ehdr), 1, fp);

    // 判断是否ELF文件
    if (elf_head.e_ident[0] != 0x7F || elf_head.e_ident[1] != 'E' ||
        elf_head.e_ident[2] != 'L' || elf_head.e_ident[3] != 'F')
    {
        printf("Not an ELF file\n");
        exit(0);
    }
    // 打印程序头表、节头表信息
    printf("程序头表偏移:%-#8x\n", elf_head.e_phoff);
    printf("程序头表总大小:%-#8x\n", elf_head.e_phentsize * elf_head.e_phnum);
    printf("程序头数目:%-8d\n", elf_head.e_phnum);
    printf("节头表偏移:%-#8x\n", elf_head.e_shoff);
    printf("节头表总大小:%-#8x\n", elf_head.e_shentsize * elf_head.e_shnum);
    printf("节头表数目:%-8d\n\n", elf_head.e_shnum);

    // 读取程序头表信息
    Elf64_Phdr *phdr = (Elf64_Phdr *)malloc(sizeof(Elf64_Phdr) * elf_head.e_phnum);
    // 定位到e_phoff程序头表偏移处
    fseek(fp, elf_head.e_phoff, SEEK_SET);
    // 读取所有程序头
    fread(phdr, sizeof(Elf64_Phdr) * elf_head.e_phnum, 1, fp);
    rewind(fp);

    // 输出每个程序头的信息
    for (int i = 0; i < elf_head.e_phnum; ++i)
    {
        printf("段偏移:%-#8x\t", phdr[i].p_offset);
        printf("段虚拟地址:%-#8x\t", phdr[i].p_vaddr);
        printf("文件中段长度:%-#8x\t", phdr[i].p_filesz);
        printf("内存中段长度:%-#8x\n", phdr[i].p_memsz);
    }
    printf("\n");

    // 读取节头表信息
    Elf64_Shdr *shdr = (Elf64_Shdr *)malloc(sizeof(Elf64_Shdr) * elf_head.e_shnum);

    // 设置文件偏移量，定位到e_shoff
    fseek(fp, elf_head.e_shoff, SEEK_SET);

    // 读取所有节头
    fread(shdr, sizeof(Elf64_Shdr) * elf_head.e_shnum, 1, fp);
    rewind(fp);

    // 输出每个节头的信息
    fseek(fp, shdr[elf_head.e_shstrndx].sh_offset, SEEK_SET);
    // e_shstrndx项是字符串表.shstrtab的下标，对应节名
    char shstrtab[shdr[elf_head.e_shstrndx].sh_size];

    // 读取所有节名
    fread(shstrtab, shdr[elf_head.e_shstrndx].sh_size, 1, fp);
    // 输出每个节的信息
    for (int i = 0; i < elf_head.e_shnum; ++i)
    {
        // shdr[i].sh_name表示当前节名在.shstrtab节内容中的偏移
        printf("节名:%-20s\t", shstrtab + shdr[i].sh_name);
        printf("节偏移:%-#8x\t", shdr[i].sh_offset);
        printf("节长度:%-#8x\t", shdr[i].sh_size);
        printf("节运行时虚拟地址:%-#8x\n", shdr[i].sh_addr);
    }
    system("pause");
    return 0;
}
// gcc /home/hacker/lab1.cpp -o /home/hacker/lab1 -lstdc++
// /home/hacker/lab1
// /challenge/easy_re