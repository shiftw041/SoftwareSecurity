# �����������
# �ַ���������һ��G
table="1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFHJKLZXCVBNM-+/"
timess = 0

# Ŀ����
target_result = "pL97"
original_input = ""

# �ھ�λ
for temp0 in range(0x30, 0x7b):
    if table[(temp0 >> 2) & 0x3F] == target_result[0]:
        original_input += chr(temp0)
        print("NO", timess, "is", hex(temp0), chr(temp0))
        timess += 1
        # ��ʮλ
        for temp1 in range(0x30, 0x7b):
            t = ((temp1 >> 4) & 0x0F) | ((16 * ord(original_input[0])) & 0x30)
            if  t <= 64 and t >= 0 and table[t] == target_result[1]:
                original_input += chr(temp1)
                print("NO", timess, "is", hex(temp1), chr(temp1))
                timess += 1
                # ��ʮһλ
                for temp2 in range(0x30, 0x7b):
                    t = ((temp2 >> 6) & 3) | ((4 * ord(original_input[1])) & 0x3C)
                    if t <= 64 and t >= 0 and table[t] == target_result[2]:
                        original_input += chr(temp2)
                        print("NO", timess, "is", hex(temp2), chr(temp2))
                        timess += 1 
                        # ��ʮ��λ
                        for temp3 in range(0x30, 0x7b):
                            t = temp3 ^ ord(original_input[2]) & 0x3F
                            if t <= 64 and t >= 0 and table[t] == target_result[3]:
                                original_input += chr(temp3)
                                print("NO", timess, "is", hex(temp3), chr(temp3))
                                timess += 1
                                if(timess == 4):
                                    break
                                else:
                                    original_input = original_input[:3]
                                    timess -= 1
                        if(timess == 4):    
                            break
                        else:
                            original_input = original_input[:2]
                            timess -= 1
                if(timess == 4):    
                    break
                else:
                    original_input = original_input[:1]
                    timess -= 1
        if(timess == 4):
            break
        else:
            print("Failed Input:", original_input, "\n")
            original_input = ""
            timess = 0
# ��������������������OR06
print("Original Input:", original_input)
# v[8] = table[(*sb >> 2) & 0x3F];
# v[9] = table[(sb[1] >> 4) & 0xF | (16 * sb[0]) & 0x30];
# v[10] = table[(sb[2] >> 6) & 3 | (4 * sb[1]) & 0x3C];
# v[11] = table[(unsigned __int8)sb[3] ^ sb[2] & 0x3F];