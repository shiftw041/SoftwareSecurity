# 爆破第四部分licence
import hashlib

# 字符表
table="1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFHJKLZXCVBNMG"

# 目标结果, 存在ans后面
target_result = "ECCFB519"

# 枚举密码
class enddd(Exception):
      pass
try:
      for char1 in table:
            for char2 in table:
                  for char3 in table:
                        for char4 in table:
                              password = char1 + char2 + char3 + char4
                              print("try", password)
                              # 统一转换为大写，md5码其实是128位二进制以十六进制字符串形式给出
                              md5 = hashlib.md5(password.encode('utf-8')).hexdigest().upper()
                              if md5[24:32] == "ECCFB519":
                                    print("flag is zhengde:", password)
                                    raise enddd()
      print("Password not found.")       

except enddd:
      pass
# 最后得到可行的一个licence为zm4R
# 总的可行解为DiQJ-xTpH-OR06-zm4R

'''--------------------
解题过程
      第一部分的值其实是最后才比较, 比对结果放在ans里
      第二部分和第三部分都是对原文进行处理后比较, 直接一层层穷举就行, 没用z3
      不过要注意这部分结果不一定是唯一的, 如第二部分的操作其实只用关注字符的高六位, 所以产生多种可行方案
      第四部分一开始犯了一个错误, 代码中也没有strcmp的具体实现, 所以以为只比较前四位也就是第一部分
      误以为第四部分的比较不在strcmp中而是嵌入到MD5过程中, 加上那段汇编代码难以阅读，属实是没搞懂就搞错了
      还有就是密文的值不是常规字符, 我误以为是无关紧要的数据,,,,,
      而且没看出取的是md5的最后8个十六进制位, md5那段代码是真的看不懂啊就以为是啥重构过的加密过程
      其实就是传统的md5加密, 自己想复杂了, 直接穷举爆破很容易就出结果了
gdb调试
      参考文章:
      https://blog.csdn.net/u012121468/article/details/80684813
      https://blog.csdn.net/StarRain2016/article/details/119779616

      进入gdb ./easy_re
      运行程序 r/run, start
      !!设置内存set *addr = 0x1234
      !!设置寄存器set $PC = 0x123 设置指令寄存器值为汇编指令地址, 由此可以实现人工跳转
      下一步ni, n/next, si, s/step 加了i的是汇编级别, 不加是c语言
      继续运行到断点c/continue
      跳出函数并返回结果finish
      !!查看内存 x /fmt 0x000123824u其中/fmt是格式化输出设置, 如/x /o /s /i是显示汇编指令
      !!监视display /fmt格式 <exp表达式> <addr地址>
      查看汇编代码disassemble main
      查看信息info register/
      打印print
      显示汇编代码窗口layout
      打断点用 b *0x1231或b *main+12,但是注意进入gbd的时候要加完整路径，否则无法打断点（或者有时候需要运行了才得到真正的物理地址）

IDA
      用gragh视图理解程序结构, 空格切换代码视图
      f5生成c垃圾c代码
      理论上可以在实验云主机上用动态调试, 但是不知道为什么运行不了, 相关资料少, 放弃配置, 直接改用gdb调试

# 计算第二部分
# 字符表，少了一个G
table="1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFHJKLZXCVBNM-+/"
timess = 1

# 逆向操作
def reverse_operation(temp):
    return table[((temp >> 2)^(ord(original_input[timess-1])>>2)) & 0x3F]
# 目标结果
target_result = "xw0t"

# 模拟爆破
original_input = chr(0)
for i in range(4):
    for temp in range(0x30, 0x7b):
        if reverse_operation(temp) == target_result[timess-1]:
            original_input += chr(temp)
            print("NO", timess, "is", hex(temp),chr(temp))
            timess += 1
            break
# 最后分析出第二部分密码为xTpH，实际上可能的结果有多种，因为第二部分密码只需要关注每个字符码的前六位
print("Original Input:", original_input)
# v[4] = table[(sa[0] >> 2) & 0x3F];
# v11 = 5;
# for (j = 1; j <= 3; ++j){
#    v5 = v11++;
#    v[v5] = table[((unsigned __int8)(sa[j] >> 2) ^ (unsigned __int8)(sa[j - 1] >> 2)) & 0x3F];
# }

# 计算第三部分
# 字符表，少了一个G
table="1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFHJKLZXCVBNM-+/"
timess = 0

# 目标结果
target_result = "pL97"
original_input = ""

# 第九位
for temp0 in range(0x30, 0x7b):
    if table[(temp0 >> 2) & 0x3F] == target_result[0]:
        original_input += chr(temp0)
        print("NO", timess, "is", hex(temp0), chr(temp0))
        timess += 1
        # 第十位
        for temp1 in range(0x30, 0x7b):
            t = ((temp1 >> 4) & 0x0F) | ((16 * ord(original_input[0])) & 0x30)
            if  t <= 64 and t >= 0 and table[t] == target_result[1]:
                original_input += chr(temp1)
                print("NO", timess, "is", hex(temp1), chr(temp1))
                timess += 1
                # 第十一位
                for temp2 in range(0x30, 0x7b):
                    t = ((temp2 >> 6) & 3) | ((4 * ord(original_input[1])) & 0x3C)
                    if t <= 64 and t >= 0 and table[t] == target_result[2]:
                        original_input += chr(temp2)
                        print("NO", timess, "is", hex(temp2), chr(temp2))
                        timess += 1 
                        # 第十二位
                        for temp3 in range(0x30, 0x7b):
                            t = temp3 ^ ord(original_input[2]) & 0x3F
                            if t <= 64 and t >= 0 and table[t] == target_result[3]:
                                original_input += chr(temp3)
                                print("NO", timess, "is", hex(temp3), chr(temp3))
                                timess += 1
                                if(timess == 4):
                                    break
                                else:
                                    original_input = original_input[:3]
                                    timess -= 1
                        if(timess == 4):    
                            break
                        else:
                            original_input = original_input[:2]
                            timess -= 1
                if(timess == 4):    
                    break
                else:
                    original_input = original_input[:1]
                    timess -= 1
        if(timess == 4):
            break
        else:
            print("Failed Input:", original_input, "\n")
            original_input = ""
            timess = 0
# 最后分析出第三部分密码OR06
print("Original Input:", original_input)
# v[8] = table[(*sb >> 2) & 0x3F];
# v[9] = table[(sb[1] >> 4) & 0xF | (16 * sb[0]) & 0x30];
# v[10] = table[(sb[2] >> 6) & 3 | (4 * sb[1]) & 0x3C];
# v[11] = table[(unsigned __int8)sb[3] ^ sb[2] & 0x3F];


IDA生成的c代码
int __fastcall main(int argc, const char **argv, const char **envp)
{
    int v3;          // eax
    int v4;          // eax
    int v5;          // eax
    int v6;          // eax
    unsigned int v8; // eax
    int v9;          // eax
    int v10;         // [rsp+0h] [rbp-90h]
    int v11;         // [rsp+0h] [rbp-90h]
    int v12;         // [rsp+0h] [rbp-90h]
    int i;           // [rsp+4h] [rbp-8Ch]
    int j;           // [rsp+4h] [rbp-8Ch]
    int k;           // [rsp+4h] [rbp-8Ch]
    char *s;         // [rsp+8h] [rbp-88h]第一部分
    char *sa;        // [rsp+8h] [rbp-88h]第二部分
    char *sb;        // [rsp+8h] [rbp-88h]第三部分
    const char *sc;  // [rsp+8h] [rbp-88h]第四部分
    char v20[96];    // [rsp+10h] [rbp-80h] BYREF
    char v21[24];    // [rsp+70h] [rbp-20h] BYREF
    // unsigned __int64 v22; // [rsp+88h] [rbp-8h]
    char v[4];
    char s1[4];
    char s2[9] = "xw0tpL97";
    char byte_405188[120];
    char inp[104];
    // 字符表少了一个G
    char table[65] = "1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFHJKLZXCVBNM-+/";

    // 防止栈溢出v22 = __readfsqword(0x28u);
    memset(v, 0, 0x64uLL); // 初始化v数组
    puts("Show your license");
    // 接收用户输入__isoc99_scanf("%s", inp);
    if (strlen(inp) == 19) // 判断长度是否合法
    {
        v10 = 0;
        // 取第一部分放入s和v[4]
        s = strtok(inp, hyphen); // 分段函数根据连字符hyphen分段
        for (i = 0; i <= 3; ++i)
        {
            v3 = v10++;
            v[v3] = s[i];
        }
        // 取第二部分放入sa，并执行移位异或操作，结果放入s1（v4-8）
        sa = strtok(0LL, hyphen);
        v4 = v10;
        v11 = v10 + 1;
        v[v4] = table[(*sa >> 2) & 0x3F];
        for (j = 1; j <= 3; ++j)
        {
            v5 = v11++;
            v[v5] = table[((unsigned __int8)(sa[j] >> 2) ^ (unsigned __int8)(sa[j - 1] >> 2)) & 0x3F];
        }
        // 对比生成的字符串是否符合结果
        if (strncmp(s1, s2, 4uLL))
        {
            puts("Second part is wrong");
            return 0;
        }
        puts("Second part is right");
        // 取第三部分放入sb
        sb = strtok(0LL, hyphen);
        // 注意，每一部分的可能结果都有多种，而且与上一部分的选择结果相关联
        // 注意枚举的时候使用范围内的字符
        v[v11] = table[(*sb >> 2) & 0x3F];
        v[v11 + 1] = table[(sb[1] >> 4) & 0xF | (16 * sb[0]) & 0x30];
        v[v11 + 2] = table[(sb[2] >> 6) & 3 | (4 * sb[1]) & 0x3C];
        v6 = v11 + 3;
        v12 = v11 + 4;
        v[v6] = table[(unsigned __int8)sb[3] ^ sb[2] & 0x3F];
        if (strncmp(byte_405188, &s2[4], 4uLL))
        {
            puts("Third part is wrong");
            return 0;
        }
        puts("Third part is right");
        sc = strtok(0LL, hyphen);
        MD5Init(v20);// 初始化MD5
        v8 = strlen(sc);
        MD5Update(v20, sc, v8);//v20用来保存MD5的状态信息
        //sc是待处理的数据块，v8是待处理数据块的字节数
        MD5Final(v20, v21);// md5值放入v21中
        for (k = 12; k <= 15; ++k)//取md5的后八个十六进制位作为处理结果
        {
            v[k] = v21[k];
        }
        // 对比licence的全部
        if (!strcmp(v, ans))
        {
            puts("Great, here is your flag");
            read_flag();
            return 0;
        }
        puts("Oops, wrong");
    }
    else
    {
        puts("Oops, wrong");
    }
    return 0;
}
'''